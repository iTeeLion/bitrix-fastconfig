# bitrix-component-sample
Sample clear component for bitrix
